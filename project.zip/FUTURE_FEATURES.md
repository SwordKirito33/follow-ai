# 未来功能清单 🚀

## 📝 已记录的功能

### 1. 浏览时间弹出登录/注册界面 ⏰

**功能描述**：
- 当用户浏览网站10-20秒后，如果未登录，自动弹出登录/注册提示框
- 鼓励用户注册以获取更好的体验

**实现计划**：
- 使用 `useEffect` 和 `setTimeout` 跟踪用户浏览时间
- 检测用户是否已登录（通过 `useAuth`）
- 如果未登录且浏览时间达到阈值，显示模态框
- 提供关闭选项，避免打扰用户体验
- 使用 `localStorage` 记录用户是否已关闭过提示（避免频繁弹出）

**代码位置**：
- 可以在 `App.tsx` 或创建一个 `VisitTracker` 组件
- 使用 `AuthModal` 组件显示登录/注册界面

**实现示例**：
```typescript
// 在 App.tsx 或新组件中
useEffect(() => {
  if (!isAuthenticated) {
    const timer = setTimeout(() => {
      const hasSeenPrompt = localStorage.getItem('hasSeenAuthPrompt');
      if (!hasSeenPrompt) {
        setShowAuthPrompt(true);
      }
    }, 15000); // 15秒后弹出
    
    return () => clearTimeout(timer);
  }
}, [isAuthenticated]);
```

**注意事项**：
- 不要过于频繁弹出，影响用户体验
- 提供明显的关闭按钮
- 可以考虑在用户滚动到页面底部时再弹出
- 记录用户选择，避免重复打扰

---

## 🎨 UI/UX 改进建议

### 1. 微交互动画
- ✅ 已添加：模态框淡入、滑入动画
- ✅ 已添加：按钮悬停效果
- 🔄 待添加：页面切换过渡动画
- 🔄 待添加：卡片悬停3D效果
- 🔄 待添加：加载骨架屏动画

### 2. 响应式优化
- ✅ 已实现：基础响应式布局
- 🔄 待优化：移动端导航菜单动画
- 🔄 待优化：移动端表单输入体验
- 🔄 待优化：触摸手势支持

### 3. 交互反馈
- ✅ 已添加：表单验证错误提示
- ✅ 已添加：成功/失败消息提示
- 🔄 待添加：操作确认对话框
- 🔄 待添加：加载状态指示器
- 🔄 待添加：空状态插画

### 4. 性能优化
- 🔄 待实现：图片懒加载
- 🔄 待实现：代码分割
- 🔄 待实现：虚拟滚动（长列表）
- 🔄 待实现：服务端渲染（SSR）

---

## 🔧 功能增强

### 1. 用户系统
- ✅ 已完成：登录/注册
- ✅ 已完成：退出登录
- ✅ 已完成：编辑资料
- 🔄 待实现：邮箱验证
- 🔄 待实现：密码重置
- 🔄 待实现：社交登录（Google, GitHub）
- 🔄 待实现：用户头像上传

### 2. 评测系统
- ✅ 已完成：提交评测表单
- 🔄 待实现：评测草稿保存
- 🔄 待实现：评测编辑/删除
- 🔄 待实现：评测点赞/收藏
- 🔄 待实现：评测评论系统

### 3. 通知系统
- 🔄 待实现：站内消息通知
- 🔄 待实现：邮件通知设置
- 🔄 待实现：浏览器推送通知
- 🔄 待实现：任务提醒

### 4. 搜索功能
- 🔄 待实现：工具搜索
- 🔄 待实现：评测搜索
- 🔄 待实现：高级筛选
- 🔄 待实现：搜索历史

---

## 📊 数据分析

### 1. 用户行为追踪
- 🔄 待实现：页面浏览统计
- 🔄 待实现：用户行为热力图
- 🔄 待实现：转化率追踪
- 🔄 待实现：A/B测试框架

### 2. 邮件营销
- ✅ 已收集：用户邮箱
- 🔄 待实现：邮件模板系统
- 🔄 待实现：邮件发送队列
- 🔄 待实现：邮件打开率追踪
- 🔄 待实现：邮件退订管理

---

## 🎯 优先级排序

### 高优先级（1-2周）
1. ✅ 登录/注册系统
2. ✅ 退出登录功能
3. ✅ 编辑资料功能
4. 🔄 浏览时间弹出登录提示
5. 🔄 邮箱验证

### 中优先级（1个月）
1. 🔄 密码重置
2. 🔄 评测编辑/删除
3. 🔄 搜索功能
4. 🔄 图片懒加载

### 低优先级（2-3个月）
1. 🔄 社交登录
2. 🔄 评论系统
3. 🔄 通知系统
4. 🔄 邮件营销系统

---

## 📝 实现笔记

### 浏览时间弹出功能详细设计

**触发条件**：
- 用户未登录
- 浏览时间达到10-20秒（可配置）
- 用户未主动关闭过提示
- 用户未在填写表单

**用户体验**：
- 使用优雅的动画弹出
- 提供明确的关闭按钮
- 不要遮挡重要内容
- 可以延迟到用户停止滚动时再显示

**技术实现**：
```typescript
// components/VisitTracker.tsx
import { useEffect, useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import AuthModal from './AuthModal';

const VisitTracker: React.FC = () => {
  const { isAuthenticated } = useAuth();
  const [showPrompt, setShowPrompt] = useState(false);
  const [hasInteracted, setHasInteracted] = useState(false);

  useEffect(() => {
    if (isAuthenticated) return;

    const hasSeenPrompt = localStorage.getItem('hasSeenAuthPrompt');
    if (hasSeenPrompt === 'true') return;

    // 检测用户交互
    const handleInteraction = () => {
      setHasInteracted(true);
    };
    
    window.addEventListener('scroll', handleInteraction);
    window.addEventListener('click', handleInteraction);

    // 15秒后弹出
    const timer = setTimeout(() => {
      if (!hasInteracted) {
        setShowPrompt(true);
      }
    }, 15000);

    return () => {
      clearTimeout(timer);
      window.removeEventListener('scroll', handleInteraction);
      window.removeEventListener('click', handleInteraction);
    };
  }, [isAuthenticated, hasInteracted]);

  const handleClose = () => {
    setShowPrompt(false);
    localStorage.setItem('hasSeenAuthPrompt', 'true');
  };

  return (
    <AuthModal
      isOpen={showPrompt}
      onClose={handleClose}
      initialMode="signup"
    />
  );
};
```

---

**最后更新**：2025-01-XX
**维护者**：开发团队

