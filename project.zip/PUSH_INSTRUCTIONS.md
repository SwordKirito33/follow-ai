# 如何 Push 代码到 GitHub

## 🚀 方法 1：使用终端（推荐）

### 步骤：

1. **打开终端**，进入项目目录：
```bash
cd ~/Downloads/follow.ai
```

2. **添加所有更改的文件**：
```bash
git add .
```

3. **提交更改**（使用有意义的提交信息）：
```bash
git commit -m "添加多语言支持功能 (i18n)"
```

4. **推送到 GitHub**：
```bash
git push origin main
```

### 完整命令序列：

```bash
cd ~/Downloads/follow.ai
git add .
git commit -m "添加多语言支持功能 (i18n)"
git push origin main
```

---

## 🖱️ 方法 2：使用 VS Code / Cursor 的 Git 功能

### 步骤：

1. **打开 Source Control 面板**：
   - 点击左侧边栏的"Source Control"图标（或按 `Ctrl+Shift+G` / `Cmd+Shift+G`）

2. **查看更改**：
   - 你会看到所有修改的文件（显示 "M" 标记）
   - 还有未跟踪的新文件（显示 "U" 标记）

3. **暂存所有更改**：
   - 点击 "Changes" 旁边的 "+" 号（或点击 "Stage All Changes"）
   - 或者点击每个文件旁边的 "+" 号单独暂存

4. **提交更改**：
   - 在顶部的输入框输入提交信息：`添加多语言支持功能 (i18n)`
   - 点击 "✓ Commit" 按钮（或按 `Cmd+Enter`）

5. **推送到 GitHub**：
   - 点击右上角的 "..." 菜单
   - 选择 "Push" 或 "Push to..."
   - 或者点击状态栏的同步图标

---

## 📋 当前需要提交的文件

### 修改的文件：
- `App.tsx` - 添加了 LanguageProvider
- `components/Hero.tsx` - 使用翻译
- `components/Navbar.tsx` - 添加语言选择器
- `components/Rankings.tsx` - 使用翻译
- `pages/Home.tsx` - 使用翻译
- `pages/Tasks.tsx` - 使用翻译

### 新文件：
- `components/Footer.tsx` - 新的页脚组件
- `components/LanguageSelector.tsx` - 语言选择器组件
- `contexts/LanguageContext.tsx` - 语言Context
- `i18n/` - 翻译文件目录
  - `i18n/index.ts`
  - `i18n/locales/en.ts` - 英文翻译
  - `i18n/locales/zh.ts` - 中文翻译
- `BUSINESS_ANALYSIS.md` - 商业分析文档
- `DEPLOYMENT_GUIDE.md` - 部署指南
- `I18N_GUIDE.md` - 多语言使用指南

---

## ✅ Push 后的流程

1. **GitHub 接收代码**（几秒钟）
2. **Vercel 自动检测到 push**（几秒钟）
3. **Vercel 开始构建**（1-2分钟）
4. **Vercel 部署到生产环境**（1-2分钟）
5. **网站自动更新** ✅

**总时间：约 3-5 分钟**

---

## 🔍 如何确认 Push 成功

### 1. 检查 GitHub
- 访问：https://github.com/SwordKirito33/follow-ai
- 查看最新的 commit 是否出现

### 2. 检查 Vercel
- 登录 [Vercel Dashboard](https://vercel.com/dashboard)
- 查看你的项目
- 在 "Deployments" 标签页查看最新的部署
- 绿色 ✅ = 成功
- 红色 ❌ = 失败（查看日志）

### 3. 检查网站
- 等待 3-5 分钟后
- 刷新你的网站
- 检查右上角是否有语言选择器（地球图标）

---

## ⚠️ 如果 Push 失败

### 常见错误和解决方案：

1. **"Permission denied"**
   - 需要配置 GitHub Personal Access Token
   - 参考之前的配置步骤

2. **"Remote origin already exists"**
   - 已经配置好了，直接 push 即可

3. **"Nothing to commit"**
   - 所有更改已经提交了
   - 直接 `git push` 即可

4. **"Updates were rejected"**
   - 远程有新的更改
   - 先执行：`git pull origin main`
   - 然后再：`git push origin main`

---

## 💡 快速 Push 命令（一键执行）

如果你想一次性执行所有步骤，可以运行：

```bash
cd ~/Downloads/follow.ai && git add . && git commit -m "添加多语言支持功能 (i18n)" && git push origin main
```

---

## 🎯 推荐方式

**最简单的方式**：在 Cursor/VS Code 中：
1. 点击左侧 "Source Control" 图标
2. 点击 "Stage All Changes" (+)
3. 输入提交信息
4. 点击 "Commit"
5. 点击 "Push" 或同步图标

**或者**：直接复制粘贴终端命令：
```bash
git add . && git commit -m "添加多语言支持功能 (i18n)" && git push origin main
```

---

**Push 完成后，等待 3-5 分钟，你的网站就会自动更新！** 🚀

